extends RefCounted
# Shared ship model for the cover and the flight scene.
# The nose points toward -Z. Returns the engine plumes and lights so the caller can animate them.

const CYAN: Color = Color(0.6, 0.78, 0.9)


static func build(parent: Node3D) -> Dictionary:
	var hull := StandardMaterial3D.new()
	hull.albedo_texture = load("res://assets/ship_hull_albedo.png")
	hull.normal_enabled = true
	hull.normal_texture = load("res://assets/ship_hull_normal.png")
	hull.roughness_texture = load("res://assets/ship_hull_roughness.png")
	hull.roughness = 1.0
	hull.metallic = 0.55

	var dark := StandardMaterial3D.new()
	dark.albedo_color = Color(0.05, 0.07, 0.10)
	dark.metallic = 0.7
	dark.roughness = 0.35

	var canopy := StandardMaterial3D.new()
	canopy.albedo_color = Color(0.1, 0.35, 0.6, 0.7)
	canopy.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	canopy.metallic = 0.9
	canopy.roughness = 0.05
	canopy.emission_enabled = true
	canopy.emission = Color(0.05, 0.3, 0.6)
	canopy.emission_energy_multiplier = 0.4

	var flame_mat := StandardMaterial3D.new()
	flame_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	flame_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	flame_mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	flame_mat.albedo_color = Color(0.55, 0.78, 0.95, 0.6)

	var fuselage := CylinderMesh.new()
	fuselage.top_radius = 0.22
	fuselage.bottom_radius = 0.14
	fuselage.height = 2.0
	fuselage.radial_segments = 24
	_part(parent, fuselage, Vector3.ZERO, Vector3(90.0, 0.0, 0.0), hull)

	var nose := CylinderMesh.new()
	nose.top_radius = 0.02
	nose.bottom_radius = 0.14
	nose.height = 0.7
	nose.radial_segments = 24
	_part(parent, nose, Vector3(0.0, 0.0, -1.35), Vector3(-90.0, 0.0, 0.0), hull)

	var wing := BoxMesh.new()
	wing.size = Vector3(2.6, 0.035, 0.7)
	_part(parent, wing, Vector3(0.0, -0.02, 0.2), Vector3.ZERO, hull)

	var fin := BoxMesh.new()
	fin.size = Vector3(0.04, 0.5, 0.7)
	_part(parent, fin, Vector3(0.0, 0.27, 0.75), Vector3.ZERO, hull)

	var canopy_mesh := SphereMesh.new()
	canopy_mesh.radius = 0.2
	canopy_mesh.height = 0.4
	canopy_mesh.radial_segments = 24
	canopy_mesh.rings = 12
	var canopy_node: MeshInstance3D = _part(parent, canopy_mesh, Vector3(0.0, 0.16, -0.5), Vector3.ZERO, canopy)
	canopy_node.scale = Vector3(1.0, 0.6, 1.6)

	for side in [-1.0, 1.0]:
		var tip := SphereMesh.new()
		tip.radius = 0.05
		tip.height = 0.1
		_part(parent, tip, Vector3(1.3 * side, 0.0, 0.2), Vector3.ZERO, _glow(CYAN, 1.5))

	var flames: Array = []
	var lights: Array = []
	for side in [-1.0, 1.0]:
		var engine_x: float = 0.42 * side
		var nozzle := CylinderMesh.new()
		nozzle.top_radius = 0.16
		nozzle.bottom_radius = 0.13
		nozzle.height = 0.5
		nozzle.radial_segments = 20
		_part(parent, nozzle, Vector3(engine_x, -0.02, 1.1), Vector3(90.0, 0.0, 0.0), dark)

		var plume := CylinderMesh.new()
		plume.top_radius = 0.13
		plume.bottom_radius = 0.01
		plume.height = 0.9
		plume.radial_segments = 20
		flames.append(_part(parent, plume, Vector3(engine_x, -0.02, 1.8), Vector3(-90.0, 0.0, 0.0), flame_mat))

		var light := OmniLight3D.new()
		light.light_color = CYAN
		light.light_energy = 0.8
		light.omni_range = 4.0
		light.position = Vector3(engine_x, -0.02, 1.6)
		parent.add_child(light)
		lights.append(light)

	return {"flames": flames, "lights": lights}


static func _part(parent: Node3D, mesh: Mesh, pos: Vector3, rot_deg: Vector3, mat: Material) -> MeshInstance3D:
	var node := MeshInstance3D.new()
	node.mesh = mesh
	node.position = pos
	node.rotation_degrees = rot_deg
	node.material_override = mat
	parent.add_child(node)
	return node


static func _glow(color: Color, energy: float) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.emission_enabled = true
	material.emission = color
	material.emission_energy_multiplier = energy
	return material
