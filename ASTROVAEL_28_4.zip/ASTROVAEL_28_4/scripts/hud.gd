extends CanvasLayer
# Flight HUD: flight panel (left), nearest-planet box with the speed setting (right), route list,
# touch controls, messages, the countdown, and the pause / crash menus.
# Colours are soft amber and cream on dark glass, which is easier on the eyes in long sessions.

signal pause_pressed
signal speed_selected(index: int)
signal menu_choice(id: String)

const UniverseMap = preload("res://scripts/universe_map.gd")

const TEXT: Color = Color(0.90, 0.86, 0.78)
const ACCENT: Color = Color(0.96, 0.76, 0.50)
const GOLD: Color = Color(0.98, 0.84, 0.58)
const MUTED: Color = Color(0.70, 0.66, 0.60)
const SPEED_NAMES: Array = ["SLOW", "MEDIUM", "FAST"]
# One route unit is 1,000 miles, which is 1,609.344 km.
const UNIT_KM: float = 1609.344

var touch_left: bool = false
var touch_right: bool = false
var touch_boost: bool = false
var touch_fire: bool = false

var speed_label: Label
var travelled_label: Label
var energy_label: Label
var diamond_label: Label
var best_label: Label
var boost_bar: ProgressBar
var planet_name: Label
var planet_type: Label
var planet_facts: Label
var travelled_box: Label
var arrive_box: Label
var progress_bar: ProgressBar
var speed_button: Button
var speed_row: HBoxContainer
var speed_buttons: Array = []
var route_panel: PanelContainer
var route_label: Label
var message_label: Label
var big_label: Label
var pause_button: Button
var flash_rect: ColorRect
var flash_alpha: float = 0.0
var menu_panel: PanelContainer
var menu_title: Label
var menu_body: Label
var menu_options: VBoxContainer
var map_view
var map_readout: Label
var map_toggle: Button


# Distances in million km. units = route units (1 unit = 1,000 miles).
static func million_km(units: float) -> String:
	return "%.2f million km" % (units * UNIT_KM / 1000000.0)


# Speed in km/s. units_per_second = route units per second.
static func speed_km(units_per_second: float) -> String:
	return "%s km/s" % commas(int(round(units_per_second * UNIT_KM)))


static func commas(value: int) -> String:
	var text: String = str(absi(value))
	var out: String = ""
	var count: int = 0
	for i in range(text.length() - 1, -1, -1):
		out = text[i] + out
		count += 1
		if count % 3 == 0 and i > 0:
			out = "," + out
	return ("-" if value < 0 else "") + out


func _ready() -> void:
	layer = 6
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	flash_rect = ColorRect.new()
	flash_rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	flash_rect.color = Color(0.95, 0.88, 0.78, 0.0)
	flash_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(flash_rect)

	# Left: flight system.
	var left := PanelContainer.new()
	left.add_theme_stylebox_override("panel", _panel_style(16.0))
	left.position = Vector2(24.0, 22.0)
	left.custom_minimum_size = Vector2(300.0, 0.0)
	root.add_child(left)
	var left_col := VBoxContainer.new()
	left_col.add_theme_constant_override("separation", 6)
	left.add_child(left_col)
	left_col.add_child(_label("FLIGHT SYSTEM", 11, ACCENT))
	speed_label = _label("", 15, TEXT)
	left_col.add_child(speed_label)
	travelled_label = _label("", 13, TEXT)
	left_col.add_child(travelled_label)
	energy_label = _label("", 13, TEXT)
	left_col.add_child(energy_label)
	diamond_label = _label("", 13, TEXT)
	left_col.add_child(diamond_label)
	best_label = _label("", 12, MUTED)
	left_col.add_child(best_label)
	left_col.add_child(_label("BOOST", 11, ACCENT))
	boost_bar = _bar(ACCENT)
	left_col.add_child(boost_bar)
	left_col.add_child(_label("UNIVERSE MAP   (drag to turn · wheel to zoom)", 11, ACCENT))
	map_view = UniverseMap.new()
	left_col.add_child(map_view)
	map_readout = _label("", 11, TEXT)
	left_col.add_child(map_readout)
	map_toggle = Button.new()
	map_toggle.text = "SHOW WHOLE ROUTE"
	map_toggle.focus_mode = Control.FOCUS_NONE
	map_toggle.add_theme_font_size_override("font_size", 12)
	map_toggle.add_theme_color_override("font_color", TEXT)
	map_toggle.add_theme_stylebox_override("normal", _row_style())
	map_toggle.add_theme_stylebox_override("hover", _row_style())
	map_toggle.pressed.connect(_on_map_toggle)
	left_col.add_child(map_toggle)

	# Right: the nearest planet only, with distance travelled and distance left.
	var right := PanelContainer.new()
	right.add_theme_stylebox_override("panel", _panel_style(16.0))
	right.anchor_left = 1.0
	right.anchor_right = 1.0
	right.offset_left = -344.0
	right.offset_right = -24.0
	right.offset_top = 22.0
	right.custom_minimum_size = Vector2(320.0, 0.0)
	root.add_child(right)
	var right_col := VBoxContainer.new()
	right_col.add_theme_constant_override("separation", 6)
	right.add_child(right_col)
	right_col.add_child(_label("NEAREST PLANET", 11, ACCENT))
	planet_name = _label("", 24, GOLD)
	right_col.add_child(planet_name)
	planet_type = _label("", 13, TEXT)
	right_col.add_child(planet_type)
	planet_facts = _label("", 12, MUTED)
	right_col.add_child(planet_facts)
	right_col.add_child(HSeparator.new())
	travelled_box = _label("", 15, TEXT)
	right_col.add_child(travelled_box)
	arrive_box = _label("", 15, GOLD)
	right_col.add_child(arrive_box)
	progress_bar = _bar(GOLD)
	right_col.add_child(progress_bar)

	# Speed setting. Hidden until the line is clicked; choosing a speed hides the options again.
	speed_button = Button.new()
	speed_button.focus_mode = Control.FOCUS_NONE
	speed_button.alignment = HORIZONTAL_ALIGNMENT_LEFT
	speed_button.add_theme_font_size_override("font_size", 13)
	speed_button.add_theme_color_override("font_color", TEXT)
	speed_button.add_theme_stylebox_override("normal", _row_style())
	speed_button.add_theme_stylebox_override("hover", _row_style())
	speed_button.add_theme_stylebox_override("pressed", _row_style())
	speed_button.pressed.connect(_toggle_speed_options)
	right_col.add_child(speed_button)
	speed_row = HBoxContainer.new()
	speed_row.add_theme_constant_override("separation", 8)
	speed_row.visible = false
	right_col.add_child(speed_row)
	for i in range(SPEED_NAMES.size()):
		var option := Button.new()
		option.text = SPEED_NAMES[i]
		option.focus_mode = Control.FOCUS_NONE
		option.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		option.add_theme_font_size_override("font_size", 12)
		option.add_theme_stylebox_override("normal", _row_style())
		option.add_theme_stylebox_override("hover", _row_style())
		option.pressed.connect(_pick_speed.bind(i))
		speed_row.add_child(option)
		speed_buttons.append(option)
	set_speed_level(0)

	# Route list, toggled with TAB.
	route_panel = PanelContainer.new()
	route_panel.add_theme_stylebox_override("panel", _panel_style(16.0))
	route_panel.anchor_left = 1.0
	route_panel.anchor_right = 1.0
	route_panel.offset_left = -344.0
	route_panel.offset_right = -24.0
	route_panel.offset_top = 390.0
	route_panel.visible = false
	root.add_child(route_panel)
	var route_col := VBoxContainer.new()
	route_panel.add_child(route_col)
	route_col.add_child(_label("ROUTE AHEAD   (TAB)", 11, ACCENT))
	route_label = _label("", 13, TEXT)
	route_col.add_child(route_label)

	# Centre message.
	message_label = _label("", 17, ACCENT)
	message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	message_label.anchor_left = 0.5
	message_label.anchor_right = 0.5
	message_label.offset_left = -330.0
	message_label.offset_right = 330.0
	message_label.offset_top = 120.0
	message_label.custom_minimum_size = Vector2(660.0, 0.0)
	message_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	root.add_child(message_label)

	# Big countdown / repair text in the middle of the screen.
	big_label = _label("", 72, GOLD)
	big_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	big_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	big_label.anchor_left = 0.5
	big_label.anchor_right = 0.5
	big_label.anchor_top = 0.5
	big_label.anchor_bottom = 0.5
	big_label.offset_left = -240.0
	big_label.offset_right = 240.0
	big_label.offset_top = -80.0
	big_label.offset_bottom = 80.0
	root.add_child(big_label)

	# Pause / options button at the top centre.
	pause_button = Button.new()
	pause_button.text = "II  PAUSE"
	pause_button.focus_mode = Control.FOCUS_NONE
	pause_button.anchor_left = 0.5
	pause_button.anchor_right = 0.5
	pause_button.offset_left = -70.0
	pause_button.offset_right = 70.0
	pause_button.offset_top = 22.0
	pause_button.offset_bottom = 56.0
	pause_button.add_theme_font_size_override("font_size", 13)
	pause_button.add_theme_color_override("font_color", TEXT)
	pause_button.add_theme_stylebox_override("normal", _panel_style(8.0))
	pause_button.pressed.connect(func(): pause_pressed.emit())
	root.add_child(pause_button)

	# Touch controls, bottom left.
	var touch := HBoxContainer.new()
	touch.add_theme_constant_override("separation", 10)
	touch.anchor_top = 1.0
	touch.anchor_bottom = 1.0
	touch.offset_left = 24.0
	touch.offset_right = 460.0
	touch.offset_top = -74.0
	touch.offset_bottom = -22.0
	root.add_child(touch)
	_touch_button(touch, "LEFT", func(v: bool): touch_left = v)
	_touch_button(touch, "RIGHT", func(v: bool): touch_right = v)
	_touch_button(touch, "BOOST", func(v: bool): touch_boost = v)
	_touch_button(touch, "FIRE", func(v: bool): touch_fire = v)

	# Key hints, bottom right.
	var hint := _label("A / D steer   ·   SPACE boost   ·   F fire   ·   1 2 3 speed   ·   TAB route   ·   ESC pause   ·   M menu", 11, MUTED)
	hint.anchor_left = 1.0
	hint.anchor_right = 1.0
	hint.anchor_top = 1.0
	hint.anchor_bottom = 1.0
	hint.offset_left = -760.0
	hint.offset_right = -24.0
	hint.offset_top = -34.0
	hint.offset_bottom = -12.0
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	root.add_child(hint)

	# Menus (pause, crash, save slots). Shown in the middle of the screen.
	menu_panel = PanelContainer.new()
	menu_panel.add_theme_stylebox_override("panel", _panel_style(22.0))
	menu_panel.anchor_left = 0.5
	menu_panel.anchor_right = 0.5
	menu_panel.anchor_top = 0.5
	menu_panel.anchor_bottom = 0.5
	menu_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	menu_panel.grow_vertical = Control.GROW_DIRECTION_BOTH
	menu_panel.custom_minimum_size = Vector2(480.0, 0.0)
	menu_panel.visible = false
	root.add_child(menu_panel)
	var menu_col := VBoxContainer.new()
	menu_col.add_theme_constant_override("separation", 12)
	menu_panel.add_child(menu_col)
	menu_title = _label("", 20, GOLD)
	menu_col.add_child(menu_title)
	menu_body = _label("", 13, TEXT)
	menu_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	menu_body.custom_minimum_size = Vector2(440.0, 0.0)
	menu_col.add_child(menu_body)
	menu_options = VBoxContainer.new()
	menu_options.add_theme_constant_override("separation", 8)
	menu_col.add_child(menu_options)


func _process(delta: float) -> void:
	if flash_alpha > 0.0:
		flash_alpha = maxf(0.0, flash_alpha - delta * 0.6)
		flash_rect.color.a = flash_alpha


func update(d: Dictionary) -> void:
	speed_label.text = d.get("speed_text", "")
	travelled_label.text = "TRAVELLED   %s" % d.get("travelled_text", "0")
	energy_label.text = "ENERGY   %s" % d.get("energy_text", "0")
	diamond_label.text = "DIAMONDS   %s" % d.get("diamonds_text", "0")
	best_label.text = "PERSONAL BEST   %s" % d.get("best_text", "0")
	boost_bar.value = float(d.get("boost_ratio", 1.0)) * 100.0

	var planet: Dictionary = d.get("planet", {})
	planet_name.text = String(planet.get("name", ""))
	planet_type.text = String(planet.get("type", ""))
	planet_facts.text = "GRAVITY %.2f g   ·   SURFACE %d °C\nMOONS %d   ·   %s" % [
		float(planet.get("gravity", 0.0)), int(planet.get("temp", 0)),
		int(planet.get("moons", 0)), String(planet.get("galaxy_name", ""))]
	travelled_box.text = "TRAVELLED   %s" % d.get("travelled_text", "0")
	arrive_box.text = "TO ARRIVE   %s" % d.get("remaining_text", "0")
	progress_bar.value = float(d.get("progress", 0.0)) * 100.0

	var lines: Array = d.get("route_lines", [])
	route_label.text = "\n".join(PackedStringArray(lines))


func set_route(route) -> void:
	map_view.route = route


func set_map_state(s: Dictionary) -> void:
	map_view.update_state(s)
	map_readout.text = map_view.readout()


func _on_map_toggle() -> void:
	var following: bool = map_view.toggle_follow()
	map_toggle.text = "SHOW WHOLE ROUTE" if following else "FOLLOW THE SHIP"


func set_message(text: String) -> void:
	message_label.text = text


func show_big(text: String) -> void:
	big_label.text = text


func set_flash(alpha: float) -> void:
	flash_alpha = maxf(flash_alpha, alpha)


func toggle_route() -> void:
	route_panel.visible = not route_panel.visible


func set_pause_text(text: String) -> void:
	pause_button.text = text


func set_speed_level(index: int) -> void:
	speed_button.text = "SPEED  ·  %s   (click to change)" % SPEED_NAMES[index]
	for i in range(speed_buttons.size()):
		var option: Button = speed_buttons[i]
		var color: Color = GOLD if i == index else TEXT
		option.add_theme_color_override("font_color", color)
		option.add_theme_color_override("font_hover_color", GOLD)


# options: Array of {"id": String, "text": String, "enabled": bool}
func show_menu(title_text: String, body_text: String, options: Array) -> void:
	menu_title.text = title_text
	menu_body.text = body_text
	for child in menu_options.get_children():
		menu_options.remove_child(child)
		child.queue_free()
	for opt in options:
		var button := Button.new()
		button.text = String(opt["text"])
		button.disabled = not bool(opt.get("enabled", true))
		button.focus_mode = Control.FOCUS_NONE
		button.custom_minimum_size = Vector2(440.0, 40.0)
		button.add_theme_font_size_override("font_size", 14)
		button.add_theme_color_override("font_color", TEXT)
		button.add_theme_color_override("font_hover_color", GOLD)
		button.add_theme_color_override("font_disabled_color", Color(0.45, 0.42, 0.38))
		button.add_theme_stylebox_override("normal", _row_style())
		button.add_theme_stylebox_override("hover", _row_style())
		button.add_theme_stylebox_override("disabled", _row_style())
		button.pressed.connect(_emit_choice.bind(String(opt["id"])))
		menu_options.add_child(button)
	menu_panel.visible = true


func hide_menu() -> void:
	menu_panel.visible = false


func _emit_choice(id: String) -> void:
	menu_choice.emit(id)


func _toggle_speed_options() -> void:
	speed_row.visible = not speed_row.visible


func _pick_speed(index: int) -> void:
	speed_row.visible = false
	speed_selected.emit(index)


func _row_style() -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.10, 0.08, 0.06, 0.72)
	style.border_color = Color(0.85, 0.65, 0.40, 0.45)
	style.set_border_width_all(1)
	style.set_corner_radius_all(6)
	style.content_margin_left = 10.0
	style.content_margin_right = 10.0
	style.content_margin_top = 6.0
	style.content_margin_bottom = 6.0
	return style


func _panel_style(margin: float) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.07, 0.055, 0.045, 0.84)
	style.border_color = Color(0.85, 0.65, 0.40, 0.4)
	style.set_border_width_all(1)
	style.set_corner_radius_all(9)
	style.content_margin_left = margin
	style.content_margin_right = margin
	style.content_margin_top = 12.0
	style.content_margin_bottom = 12.0
	return style


func _label(text_value: String, font_size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text_value
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return label


func _bar(color: Color) -> ProgressBar:
	var bar := ProgressBar.new()
	bar.max_value = 100.0
	bar.show_percentage = false
	bar.custom_minimum_size = Vector2(0.0, 10.0)
	var fill := StyleBoxFlat.new()
	fill.bg_color = color
	fill.set_corner_radius_all(3)
	bar.add_theme_stylebox_override("fill", fill)
	var back := StyleBoxFlat.new()
	back.bg_color = Color(0.14, 0.11, 0.09, 0.9)
	back.set_corner_radius_all(3)
	bar.add_theme_stylebox_override("background", back)
	return bar


func _touch_button(parent: Container, caption: String, setter: Callable) -> void:
	var button := Button.new()
	button.text = caption
	button.focus_mode = Control.FOCUS_NONE
	button.custom_minimum_size = Vector2(96.0, 48.0)
	button.add_theme_font_size_override("font_size", 13)
	button.add_theme_color_override("font_color", TEXT)
	button.add_theme_stylebox_override("normal", _panel_style(8.0))
	button.button_down.connect(func(): setter.call(true))
	button.button_up.connect(func(): setter.call(false))
	parent.add_child(button)
