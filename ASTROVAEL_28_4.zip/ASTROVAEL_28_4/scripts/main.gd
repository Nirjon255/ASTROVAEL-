extends Node3D
# ASTROVAEL 28.4 - endless flight.
#
# The ship and camera stay near the origin and the universe moves past them. Every object keeps its
# route position (a double-precision number) and its scene position is rebuilt each frame relative
# to the ship. This keeps the scene precise however far the ship travels, and the route never ends.
#
# Route:  one unit = 1,000 miles. Stops are planets in order (Venus first). Each planet has a
#         "lane" offset, so the ship flies past it rather than through it. When the ship passes a
#         planet, the environment blends to the next one. Every six stops the ship enters a warp
#         segment and arrives in a new galaxy with a new sky.

const RouteBuilder = preload("res://scripts/route.gd")
const HudScript = preload("res://scripts/hud.gd")
const PlanetView = preload("res://scripts/planet_view.gd")
const ShipModel = preload("res://scripts/ship_model.gd")
const SaveData = preload("res://scripts/save_data.gd")

const COVER_SCENE: String = "res://scenes/Cover.tscn"
const UNIT_MILES: float = 1000.0
const CRUISE_SPEED: float = 120.0          # 120,000 mi/s
const BOOST_SPEED: float = 170.0           # 170,000 mi/s
const WARP_SPEED: float = 260.0            # warp segment between galaxies
const SHIP_RESTING_Y: float = 0.85
const SIDE_LIMIT: float = 7.8
const SIDE_RESPONSE: float = 8.5
const TILE_LENGTH: float = 100.0
const TILES_BEHIND: int = 2
const TILES_AHEAD: int = 16
const PASS_MARGIN: float = 60.0
const ZONE_RANGE: float = 2200.0
const SKY_RADIUS: float = 24000.0
const FAR_PLANE: float = 26000.0
const HAZARD_RADIUS: float = 1.45
const PICKUP_RADIUS: float = 1.05
const ALIEN_RADIUS: float = 2.15
const SHIP_RADIUS: float = 1.0
const BOLT_RADIUS: float = 0.42
const BOLT_SPEED: float = 105.0
const ALIEN_SPEED: float = 13.5
const LANES := [-5.2, 0.0, 5.2]
const SUN_DIRECTION: Vector3 = Vector3(-0.78, 0.30, 0.55)
const BASE_AMBIENT: Color = Color(0.30, 0.27, 0.24)
# Speed levels for the whole universe: 0 = Slow, 1 = Medium, 2 = Fast.
const SPEED_SCALES: Array = [0.45, 0.7, 1.0]
# Black holes: one every 50 million km of travel (50e6 km / 1,609.344 km per unit).
const BH_INTERVAL_UNITS: float = 50000000.0 / 1609.344
# A black hole always carries the ship at least 29 million km, so the jump is always very fast.
const BH_JUMP_MIN_UNITS: float = 18000.0
const BH_TRANSIT_SECONDS: float = 60.0

var route
var rng := RandomNumberGenerator.new()
var hud
var env: Environment
var sun: DirectionalLight3D
var sky_sphere: MeshInstance3D
var sky_material: ShaderMaterial
var ship: Node3D
var ship_flames: Array = []
var camera: Camera3D
var streaks: CPUParticles3D
var rock_material: StandardMaterial3D
var station_material: StandardMaterial3D

var movers: Array = []
var tile_entries: Dictionary = {}
var planet_entries: Dictionary = {}
var hazards: Array = []
var pickups: Array = []
var aliens: Array = []
var bolts: Array = []

var ship_route_z: float = 0.0
var nearest_index: int = 0
var palette_galaxy: int = 0
var current_palette: Dictionary = {}
var target_palette: Dictionary = {}
var zone_density: float = 0.0
var zone_fog: Color = Color(0.5, 0.5, 0.5)
var zone_ambient: Color = BASE_AMBIENT
var warp_active: bool = false
var current_speed: float = CRUISE_SPEED
var steer_value: float = 0.0
var target_x: float = 0.0
var boost_energy: float = 100.0
var boost_active: bool = false
var energy: int = 0
var total_energy: int = 0
var total_diamonds: int = 0
var best_miles: int = 0
var fire_cooldown: float = 0.0
var hazard_clock: float = 0.0
var pickup_clock: float = 0.0
var alien_clock: float = 0.0
var game_over: bool = false
var paused: bool = false
var shake: float = 0.0
var elapsed: float = 0.0
var message_time: float = 0.0
var speed_level: int = 0
var time_scale: float = 0.45
var bh_state: String = "none"
var bh_units: float = 0.0
var bh_dest: int = 0
var next_bh_units: float = BH_INTERVAL_UNITS
var transit_start: float = 0.0
var transit_distance: float = 0.0
var transit_timer: float = 0.0
var black_hole_entry: Dictionary = {}
var black_hole_disk: MeshInstance3D = null
var repair_phase: String = ""
var repair_timer: float = 0.0
var repair_ring: MeshInstance3D = null
var repair_sparks: CPUParticles3D = null
var save_return: String = "pause_menu"
var camera_roll: float = 0.0
var ship_dust: CPUParticles3D = null


func _ready() -> void:
	rng.randomize()
	var saved: Dictionary = SaveData.load_data()
	best_miles = int(saved["best_miles"])
	total_energy = int(saved["total_energy"])
	total_diamonds = int(saved["total_diamonds"])
	speed_level = clampi(int(saved["speed_level"]), 0, SPEED_SCALES.size() - 1)
	time_scale = float(SPEED_SCALES[speed_level])

	route = RouteBuilder.new()
	rock_material = _plain_material(Color(0.30, 0.28, 0.26), 0.95)
	station_material = _plain_material(Color(0.055, 0.085, 0.13), 0.2)
	_build_environment()
	_build_sky()
	_build_ship()
	_build_camera()
	_build_streaks()
	_build_dust()

	hud = HudScript.new()
	add_child(hud)
	hud.pause_pressed.connect(_on_pause_pressed)
	hud.speed_selected.connect(_on_speed_selected)
	hud.menu_choice.connect(_on_menu_choice)
	hud.set_route(route)
	hud.set_speed_level(speed_level)

	palette_galaxy = 0
	current_palette = route.galaxy_palette(0)
	target_palette = current_palette
	_apply_palette()
	var pending: int = SaveData.pending_slot
	SaveData.pending_slot = -1
	var loaded: bool = pending >= 1 and _apply_slot(pending)
	_sync_world()
	if loaded:
		_show_message("LOADED SAVE SLOT %d\n\nBack in flight, from the same place" % pending, 5.0)
	else:
		var first: Dictionary = route.planet(0)
		_show_message("DEPARTING EARTH\n\nNEXT STOP   %s\n%s away" % [first["name"], HudScript.million_km(float(first["units"]))], 6.0)


# ---------------------------------------------------------------- setup

func _build_environment() -> void:
	var world_env := WorldEnvironment.new()
	env = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.02, 0.014, 0.01)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = BASE_AMBIENT
	env.ambient_light_energy = 0.6
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.adjustment_enabled = true
	env.adjustment_contrast = 1.02
	env.adjustment_saturation = 0.92
	env.adjustment_brightness = 0.92
	env.glow_enabled = true
	env.glow_intensity = 0.7
	env.glow_strength = 0.7
	env.glow_bloom = 0.04
	env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SOFTLIGHT
	env.fog_enabled = false
	env.fog_sky_affect = 0.3
	world_env.environment = env
	add_child(world_env)

	sun = DirectionalLight3D.new()
	sun.transform = Transform3D(Basis.looking_at(-SUN_DIRECTION.normalized(), Vector3.UP), Vector3.ZERO)
	sun.light_color = Color(1.0, 0.97, 0.92)
	sun.light_energy = 1.5
	sun.shadow_enabled = false
	add_child(sun)


func _build_sky() -> void:
	sky_sphere = MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = SKY_RADIUS
	mesh.height = SKY_RADIUS * 2.0
	mesh.radial_segments = 96
	mesh.rings = 48
	sky_sphere.mesh = mesh
	sky_material = ShaderMaterial.new()
	sky_material.shader = load("res://shaders/galaxy_sky.gdshader") as Shader
	sky_material.set_shader_parameter("sun_dir", SUN_DIRECTION.normalized())
	sky_sphere.material_override = sky_material
	add_child(sky_sphere)


func _build_ship() -> void:
	ship = Node3D.new()
	ship.position = Vector3(0.0, SHIP_RESTING_Y, 0.0)
	add_child(ship)
	var built: Dictionary = ShipModel.build(ship)
	ship_flames = built["flames"]


func _build_camera() -> void:
	camera = Camera3D.new()
	camera.fov = 70.0
	camera.near = 0.3
	camera.far = FAR_PLANE
	camera.position = Vector3(0.0, 2.9, 7.2)
	add_child(camera)
	camera.current = true


func _build_streaks() -> void:
	# Light streaks rush toward the camera; their speed follows the ship's speed.
	streaks = CPUParticles3D.new()
	streaks.amount = 220
	streaks.lifetime = 2.4
	streaks.preprocess = 2.4
	streaks.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	streaks.emission_box_extents = Vector3(110.0, 60.0, 160.0)
	streaks.position = Vector3(0.0, 0.0, -140.0)
	streaks.direction = Vector3(0.0, 0.0, 1.0)
	streaks.spread = 0.0
	streaks.initial_velocity_min = CRUISE_SPEED
	streaks.initial_velocity_max = CRUISE_SPEED
	streaks.gravity = Vector3.ZERO
	streaks.local_coords = false
	var streak_mesh := BoxMesh.new()
	streak_mesh.size = Vector3(0.035, 0.035, 2.2)
	var streak_mat := StandardMaterial3D.new()
	streak_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	streak_mat.albedo_color = Color(0.95, 0.9, 0.8, 0.5)
	streak_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	streak_mesh.material = streak_mat
	streaks.mesh = streak_mesh
	streaks.emitting = true
	add_child(streaks)


func _sync_world() -> void:
	_update_tiles()
	_update_planets()
	_apply_positions()


# ---------------------------------------------------------------- main loop

func _process(delta: float) -> void:
	if paused:
		return
	elapsed += delta
	_update_message_timer(delta)
	_update_palette(delta)
	# Travel, spawns and enemies run on the chosen speed. Steering, boost, firing and HUD stay real-time.
	var dt: float = delta * time_scale
	_update_life(dt)
	_spin_planets(delta)

	if game_over:
		if repair_phase != "":
			_update_repair(delta)
		_apply_positions()
		_update_zone(delta)
		_animate_ship(delta, 0.0)
		_update_camera(delta)
		_update_hud()
		return

	_read_input(delta)
	if bh_state == "transit":
		_update_transit(delta)
		_apply_positions()
		_animate_ship(delta, current_speed)
		_update_camera(delta)
		_update_streaks(current_speed)
		_update_hud()
		return
	_update_black_hole(delta)
	current_speed = _speed_now()
	ship_route_z -= current_speed * dt
	_update_passing()
	_update_tiles()
	_update_planets()
	_update_spawns(dt)
	_update_zone(delta)
	_update_entities(dt)
	_handle_fire(delta)
	_apply_positions()
	_animate_ship(delta, current_speed)
	_update_camera(delta)
	_update_streaks(current_speed)
	_update_hud()


func _unhandled_input(event: InputEvent) -> void:
	var key := event as InputEventKey
	if key == null or not key.pressed or key.echo:
		return
	match key.keycode:
		KEY_ESCAPE:
			if not game_over:
				_set_paused(not paused)
		KEY_R:
			if game_over and repair_phase == "":
				_restart()
		KEY_M:
			if game_over or paused:
				get_tree().change_scene_to_file(COVER_SCENE)
		KEY_TAB:
			hud.toggle_route()
		KEY_1:
			_on_speed_selected(0)
		KEY_2:
			_on_speed_selected(1)
		KEY_3:
			_on_speed_selected(2)


func _read_input(delta: float) -> void:
	var steer: float = 0.0
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT) or hud.touch_left:
		steer -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT) or hud.touch_right:
		steer += 1.0
	steer_value = clampf(steer, -1.0, 1.0)
	target_x = clampf(target_x + steer_value * 16.0 * delta, -SIDE_LIMIT, SIDE_LIMIT)
	ship.position.x = lerpf(ship.position.x, target_x, 1.0 - exp(-SIDE_RESPONSE * delta))

	var boost_wanted: bool = (Input.is_key_pressed(KEY_SPACE) or hud.touch_boost) and not warp_active
	boost_active = boost_wanted and boost_energy > 0.5
	if boost_active:
		boost_energy = maxf(0.0, boost_energy - 30.0 * delta)
	else:
		boost_energy = minf(100.0, boost_energy + 19.0 * delta)


func _speed_now() -> float:
	if warp_active:
		return WARP_SPEED
	return BOOST_SPEED if boost_active else CRUISE_SPEED


func traveled() -> float:
	return -ship_route_z


# ---------------------------------------------------------------- route and planets

func _update_passing() -> void:
	while traveled() > float(route.units(nearest_index)) + PASS_MARGIN:
		var passed: Dictionary = route.planet(nearest_index)
		nearest_index += 1
		_on_passed(passed)
	var nearest: Dictionary = route.planet(nearest_index)
	warp_active = bool(nearest["warp_before"])
	var galaxy: int = int(nearest["galaxy"])
	if galaxy != palette_galaxy:
		palette_galaxy = galaxy
		target_palette = route.galaxy_palette(galaxy)


func _on_passed(passed: Dictionary) -> void:
	var next: Dictionary = route.planet(nearest_index)
	var new_galaxy: bool = int(next["galaxy"]) != int(passed["galaxy"])
	var to_next: float = maxf(0.0, float(next["units"]) - traveled())
	if new_galaxy:
		hud.set_flash(0.9)
		_show_message("LEFT %s\n\nWARP SPACE\nENTERING  %s" % [
			passed["name"], route.galaxy_name(int(next["galaxy"]))], 6.0)
	else:
		_show_message("PASSED %s\n\nNEXT STOP   %s\n%s to go" % [
			passed["name"], next["name"], HudScript.million_km(to_next)], 5.0)


func _update_tiles() -> void:
	var base: int = int(floor(traveled() / TILE_LENGTH))
	var first: int = base - TILES_BEHIND
	var last: int = base + TILES_AHEAD
	for k in range(first, last + 1):
		if not tile_entries.has(k):
			_build_tile(k)
	for k in tile_entries.keys():
		if k < first:
			_remove_entry(tile_entries[k])
			tile_entries.erase(k)


func _build_tile(k: int) -> void:
	var center_z: float = -(float(k) + 0.5) * TILE_LENGTH
	var node := Node3D.new()
	add_child(node)
	var entry: Dictionary = _add_mover(node, 0.0, 0.0, center_z)
	tile_entries[k] = entry
	var galaxy: int = int(route.planet(_nearest_index_for(-center_z))["galaxy"])
	var pal: Dictionary = route.galaxy_palette(galaxy)
	var r := RandomNumberGenerator.new()
	r.seed = 100003 + k * 7919
	_build_tile_content(node, pal, r, k)


func _nearest_index_for(units_ahead: float) -> int:
	var i: int = nearest_index
	while float(route.units(i)) < units_ahead:
		i += 1
	return i


func _build_tile_content(parent: Node3D, pal: Dictionary, r: RandomNumberGenerator, k: int) -> void:
	var accent: Color = pal["accent"]
	var rail_dark := _plain_material(Color(0.0, 0.12, 0.24), 0.45)
	var rail_glow := _glow_material(accent, 0.9)
	var marker_glow := _glow_material(Color(0.85, 0.6, 0.35), 0.7)
	var gate_glow := _glow_material(Color(0.75, 0.5, 0.3), 0.8)
	var lamp_glow := _glow_material(Color(1.0, 0.36, 0.08), 1.2)

	for side in [-1.0, 1.0]:
		_tile_box(parent, Vector3(side * 12.2, 0.2, 0.0), Vector3(0.16, 0.16, TILE_LENGTH), rail_dark)
		_tile_box(parent, Vector3(side * 12.2, 0.2, 0.0), Vector3(0.055, 0.055, TILE_LENGTH), rail_glow)
	for zz in range(-45, 46, 10):
		_tile_box(parent, Vector3(0.0, -0.35, float(zz)), Vector3(0.10, 0.10, 1.7), marker_glow)
	for zz in [-25.0, 25.0]:
		var gate := MeshInstance3D.new()
		var ring := TorusMesh.new()
		ring.inner_radius = 10.2
		ring.outer_radius = 10.34
		gate.mesh = ring
		gate.rotation_degrees = Vector3(90.0, 0.0, 0.0)
		gate.position = Vector3(0.0, 1.0, zz)
		gate.material_override = gate_glow
		parent.add_child(gate)
	if k % 2 == 0:
		for side in [-1.0, 1.0]:
			_tile_box(parent, Vector3(side * 13.4, 0.4, -20.0), Vector3(0.5, 2.8, 1.1), station_material)
			_tile_box(parent, Vector3(side * 13.12, 1.35, -20.08), Vector3(0.08, 0.18, 0.72), rail_glow)
			_tile_box(parent, Vector3(side * 13.12, -0.45, -20.08), Vector3(0.08, 0.12, 0.5), lamp_glow)

	var side_pick: float = -1.0 if r.randf() < 0.5 else 1.0
	var station := Node3D.new()
	station.position = Vector3(side_pick * 20.0, r.randf_range(-1.5, 4.0), r.randf_range(-35.0, 35.0))
	parent.add_child(station)
	_tile_box(station, Vector3.ZERO, Vector3(5.8, 1.25, 3.4), station_material)
	_tile_box(station, Vector3(0.0, 0.72, -0.15), Vector3(3.7, 0.22, 2.5), station_material)
	for so in [-2.25, 2.25]:
		_tile_box(station, Vector3(so, 0.68, -0.1), Vector3(0.075, 0.045, 2.25), rail_glow)
		_tile_box(station, Vector3(so, 0.84, -1.25), Vector3(0.22, 0.10, 0.22), lamp_glow)

	for i in range(2):
		var rock := MeshInstance3D.new()
		var rock_mesh := SphereMesh.new()
		rock_mesh.radius = 1.0
		rock_mesh.height = 2.0
		rock_mesh.radial_segments = 12
		rock_mesh.rings = 6
		rock.mesh = rock_mesh
		var side_rock: float = -1.0 if i % 2 == 0 else 1.0
		rock.position = Vector3(side_rock * r.randf_range(15.0, 29.0), r.randf_range(-5.0, 10.0), r.randf_range(-48.0, 48.0))
		var s: float = r.randf_range(1.2, 3.2)
		rock.scale = Vector3(s * r.randf_range(0.8, 1.2), s * r.randf_range(0.6, 1.0), s * r.randf_range(0.8, 1.2))
		rock.material_override = rock_material
		parent.add_child(rock)


func _update_planets() -> void:
	var low: int = maxi(0, nearest_index - 1)
	var high: int = nearest_index + 3
	for i in range(low, high + 1):
		if not planet_entries.has(i):
			_build_planet(i)
	for i in planet_entries.keys():
		if i < low:
			_remove_entry(planet_entries[i]["entry"])
			planet_entries.erase(i)


func _build_planet(i: int) -> void:
	var data: Dictionary = route.planet(i)
	var view: Dictionary = PlanetView.build(data)
	var root: Node3D = view["root"]
	add_child(root)
	var entry: Dictionary = _add_mover(root, float(data["lane_x"]), float(data["lane_y"]), -float(data["units"]))
	planet_entries[i] = {"entry": entry, "body": view["body"], "clouds": view["clouds"], "pivots": view["pivots"], "spin": float(data["spin"]), "data": data}


func _spin_planets(delta: float) -> void:
	for key in planet_entries.keys():
		var p: Dictionary = planet_entries[key]
		var body: Node3D = p["body"]
		body.rotate_y(float(p["spin"]) * delta)
		var clouds: Node3D = p["clouds"]
		if is_instance_valid(clouds):
			clouds.rotate_y(float(p["spin"]) * delta * 1.3)
		for pivot in p["pivots"]:
			var moon_pivot: Node3D = pivot["node"]
			moon_pivot.rotate_y(float(pivot["speed"]) * delta)


# Environment blends toward the planet the ship is closest to, so fog, ambient light and sky change
# as it approaches and passes each world.
func _update_zone(delta: float) -> void:
	var best_blend: float = 0.0
	var best_data: Dictionary = {}
	for key in planet_entries.keys():
		var p: Dictionary = planet_entries[key]
		var rel: float = float(p["entry"]["z"]) - ship_route_z
		var blend: float = clampf(1.0 - absf(rel) / ZONE_RANGE, 0.0, 1.0)
		if blend > best_blend:
			best_blend = blend
			best_data = p["data"]
	var target_density: float = 0.0
	var target_fog: Color = zone_fog
	var target_ambient: Color = BASE_AMBIENT
	if not best_data.is_empty():
		target_density = float(best_data["fog_d"]) * best_blend
		target_fog = best_data["fog"]
		target_ambient = BASE_AMBIENT.lerp(best_data["ambient"], best_blend * 0.5)
	var t: float = 1.0 - exp(-2.0 * delta)
	zone_density = lerpf(zone_density, target_density, t)
	zone_fog = zone_fog.lerp(target_fog, t)
	zone_ambient = zone_ambient.lerp(target_ambient, t)
	env.fog_enabled = zone_density > 0.000005
	env.fog_density = zone_density
	env.fog_light_color = zone_fog
	env.ambient_light_color = zone_ambient


func _update_palette(delta: float) -> void:
	var t: float = 1.0 - exp(-1.2 * delta)
	for key in current_palette.keys():
		current_palette[key] = current_palette[key].lerp(target_palette[key], t)
	_apply_palette()


func _apply_palette() -> void:
	sky_material.set_shader_parameter("band_normal", _vec3(current_palette["band_normal"]))
	sky_material.set_shader_parameter("band_color", _vec3(current_palette["band_color"]))
	sky_material.set_shader_parameter("nebula_color", _vec3(current_palette["nebula"]))
	sky_material.set_shader_parameter("star_tint_a", _vec3(current_palette["star_a"]))
	sky_material.set_shader_parameter("star_tint_b", _vec3(current_palette["star_b"]))


func _vec3(value) -> Vector3:
	if value is Color:
		return Vector3(value.r, value.g, value.b)
	return value


# ---------------------------------------------------------------- spawning

func _update_spawns(delta: float) -> void:
	if warp_active:
		return
	hazard_clock += delta
	if hazard_clock >= 1.25:
		hazard_clock = 0.0
		if rng.randf() < 0.86:
			_spawn_hazard()
	pickup_clock += delta
	if pickup_clock >= 1.25:
		pickup_clock = 0.0
		if rng.randf() < 0.82:
			_spawn_pickup()
	alien_clock += delta
	if alien_clock >= 6.5:
		alien_clock = 0.0
		if rng.randf() < 0.78:
			_spawn_alien()


func _spawn_hazard() -> void:
	var lane: float = LANES[rng.randi_range(0, LANES.size() - 1)]
	var node := Node3D.new()
	add_child(node)
	var rock := MeshInstance3D.new()
	var rock_mesh := SphereMesh.new()
	rock_mesh.radius = 1.0
	rock_mesh.height = 2.0
	rock_mesh.radial_segments = 14
	rock_mesh.rings = 8
	rock.mesh = rock_mesh
	var size: float = rng.randf_range(0.95, 1.35)
	rock.scale = Vector3(size * rng.randf_range(0.9, 1.15), size * rng.randf_range(0.8, 1.05), size)
	rock.material_override = rock_material
	node.add_child(rock)
	var ring := MeshInstance3D.new()
	var torus := TorusMesh.new()
	torus.inner_radius = 1.35
	torus.outer_radius = 1.42
	ring.mesh = torus
	ring.rotation_degrees = Vector3(65.0, 20.0, 0.0)
	ring.material_override = _glow_material(Color(0.8, 0.55, 0.3), 0.9)
	node.add_child(ring)
	_add_entry(node, lane, rng.randf_range(0.7, 1.6), ship_route_z - rng.randf_range(110.0, 150.0), "hazards",
		{"spin": Vector3(rng.randf(), rng.randf(), rng.randf()) * 0.6})


func _spawn_pickup() -> void:
	var lane: float = LANES[rng.randi_range(0, LANES.size() - 1)]
	var node := Node3D.new()
	add_child(node)
	var gem := MeshInstance3D.new()
	var prism := PrismMesh.new()
	prism.size = Vector3(0.9, 1.25, 0.9)
	gem.mesh = prism
	gem.material_override = _glow_material(Color(0.55, 0.9, 0.75), 1.4)
	node.add_child(gem)
	var halo := MeshInstance3D.new()
	var torus := TorusMesh.new()
	torus.inner_radius = 0.72
	torus.outer_radius = 0.82
	halo.mesh = torus
	halo.rotation_degrees = Vector3(90.0, 0.0, 0.0)
	halo.material_override = _glow_material(Color(0.7, 0.85, 0.7), 1.3)
	node.add_child(halo)
	_add_entry(node, lane, 1.15, ship_route_z - rng.randf_range(86.0, 125.0), "pickups",
		{"base_y": 1.15, "phase": rng.randf() * TAU})


func _spawn_alien() -> void:
	var lane: float = LANES[rng.randi_range(0, LANES.size() - 1)]
	var node := Node3D.new()
	add_child(node)
	var hull := MeshInstance3D.new()
	var disc := SphereMesh.new()
	disc.radius = 1.7
	disc.height = 3.4
	hull.mesh = disc
	hull.scale = Vector3(1.0, 0.22, 1.0)
	hull.material_override = _plain_material(Color(0.12, 0.13, 0.18), 0.35)
	node.add_child(hull)
	var dome := MeshInstance3D.new()
	var dome_mesh := SphereMesh.new()
	dome_mesh.radius = 0.7
	dome_mesh.height = 1.0
	dome.mesh = dome_mesh
	dome.position = Vector3(0.0, 0.45, 0.0)
	dome.material_override = _glow_material(Color(1.0, 0.35, 0.18), 1.4)
	node.add_child(dome)
	var halo := MeshInstance3D.new()
	var torus := TorusMesh.new()
	torus.inner_radius = 1.8
	torus.outer_radius = 1.9
	halo.mesh = torus
	halo.rotation_degrees = Vector3(90.0, 0.0, 0.0)
	halo.material_override = _glow_material(Color(1.0, 0.35, 0.18), 2.0)
	node.add_child(halo)
	_add_entry(node, lane, rng.randf_range(0.8, 2.1), ship_route_z - rng.randf_range(145.0, 178.0), "aliens",
		{"lane": lane})


# ---------------------------------------------------------------- entities, collisions

func _update_entities(delta: float) -> void:
	var sweep_ship: float = current_speed * delta
	var sweep_alien: float = (current_speed + ALIEN_SPEED) * delta

	for alien in aliens.duplicate():
		if game_over:
			break
		alien["z"] = float(alien["z"]) + ALIEN_SPEED * delta
		alien["x"] = lerpf(float(alien["x"]), float(alien["lane"]), 1.8 * delta)
		if float(alien["z"]) > ship_route_z + 24.0:
			_remove_entry(alien)
		elif _overlaps(float(alien["x"]), float(alien["y"]), float(alien["z"]), ALIEN_RADIUS, sweep_alien):
			_end_game()

	for hazard in hazards.duplicate():
		if float(hazard["z"]) > ship_route_z + 40.0:
			_remove_entry(hazard)
			continue
		var hazard_node: Node3D = hazard["node"]
		hazard_node.rotation += hazard["spin"] * delta
		if not game_over and _overlaps(float(hazard["x"]), float(hazard["y"]), float(hazard["z"]), HAZARD_RADIUS, sweep_ship):
			_end_game()

	for pickup in pickups.duplicate():
		if float(pickup["z"]) > ship_route_z + 40.0:
			_remove_entry(pickup)
			continue
		pickup["y"] = float(pickup["base_y"]) + sin(elapsed * 2.8 + float(pickup["phase"])) * 0.18
		var pickup_node: Node3D = pickup["node"]
		pickup_node.rotation.y += 1.8 * delta
		if _overlaps(float(pickup["x"]), float(pickup["y"]), float(pickup["z"]), PICKUP_RADIUS, sweep_ship):
			_collect(pickup)

	for bolt in bolts.duplicate():
		bolt["z"] = float(bolt["z"]) - BOLT_SPEED * delta
		if float(bolt["z"]) < ship_route_z - 260.0:
			_remove_entry(bolt)
			continue
		for alien in aliens.duplicate():
			var dx: float = float(bolt["x"]) - float(alien["x"])
			var dy: float = float(bolt["y"]) - float(alien["y"])
			var dz: float = absf(float(bolt["z"]) - float(alien["z"]))
			var reach: float = ALIEN_RADIUS + BOLT_RADIUS
			if dx * dx + dy * dy < reach * reach and dz < reach + (BOLT_SPEED + ALIEN_SPEED) * delta:
				_destroy_alien(alien)
				_remove_entry(bolt)
				break


func _overlaps(ex: float, ey: float, ez: float, radius: float, sweep: float) -> bool:
	var rel_z: float = ez - ship_route_z
	var reach: float = radius + SHIP_RADIUS
	if absf(rel_z) > reach + sweep:
		return false
	var dx: float = ex - ship.position.x
	var dy: float = ey - ship.position.y
	return dx * dx + dy * dy < reach * reach


func _handle_fire(delta: float) -> void:
	fire_cooldown = maxf(0.0, fire_cooldown - delta)
	var wanted: bool = Input.is_key_pressed(KEY_F) or hud.touch_fire
	if not wanted or fire_cooldown > 0.0 or game_over:
		return
	fire_cooldown = 0.22
	for side in [-0.34, 0.34]:
		var node := Node3D.new()
		add_child(node)
		var orb := MeshInstance3D.new()
		var orb_mesh := SphereMesh.new()
		orb_mesh.radius = 0.22
		orb_mesh.height = 0.44
		orb.mesh = orb_mesh
		orb.material_override = _glow_material(Color(0.95, 0.85, 0.6), 1.8)
		node.add_child(orb)
		_add_entry(node, ship.position.x + side, ship.position.y + 0.16, ship_route_z - 3.0, "bolts")


func _collect(pickup: Dictionary) -> void:
	energy += 1
	total_energy += 1
	total_diamonds += 1
	_save()
	_remove_entry(pickup)


func _destroy_alien(alien: Dictionary) -> void:
	energy += 2
	total_energy += 2
	total_diamonds += 10
	_save()
	_spawn_explosion(float(alien["x"]), float(alien["y"]), float(alien["z"]))
	_remove_entry(alien)
	_show_message("HOSTILE DESTROYED   +10 DIAMONDS", 1.2)


func _spawn_explosion(x: float, y: float, z: float) -> void:
	var burst := CPUParticles3D.new()
	burst.local_coords = true
	burst.amount = 28
	burst.one_shot = true
	burst.explosiveness = 1.0
	burst.lifetime = 0.55
	burst.direction = Vector3.UP
	burst.spread = 180.0
	burst.gravity = Vector3(0.0, -1.5, 0.0)
	burst.initial_velocity_min = 4.0
	burst.initial_velocity_max = 11.0
	burst.scale_amount_min = 0.08
	burst.scale_amount_max = 0.24
	var spark := SphereMesh.new()
	spark.radius = 0.1
	spark.height = 0.2
	burst.mesh = spark
	burst.material_override = _glow_material(Color(1.0, 0.55, 0.2), 2.8)
	add_child(burst)
	burst.emitting = true
	_add_mover(burst, x, y, z, 0.9)


func _end_game() -> void:
	if game_over:
		return
	game_over = true
	boost_active = false
	shake = 0.9
	hud.set_flash(0.35)
	var final_miles: int = int(round(traveled() * UNIT_MILES))
	best_miles = maxi(best_miles, final_miles)
	_save()
	hud.set_pause_text("OPTIONS")
	_show_message("", 0.0)
	_show_crash_menu()


# ---------------------------------------------------------------- entry bookkeeping

func _add_mover(node: Node3D, x: float, y: float, z: float, life: float = -1.0) -> Dictionary:
	var entry: Dictionary = {"node": node, "x": x, "y": y, "z": z, "life": life}
	movers.append(entry)
	return entry


func _add_entry(node: Node3D, x: float, y: float, z: float, list_name: String, extra: Dictionary = {}) -> Dictionary:
	var entry: Dictionary = {"node": node, "x": x, "y": y, "z": z, "life": -1.0, "list_name": list_name}
	entry.merge(extra)
	movers.append(entry)
	_list_for(list_name).append(entry)
	return entry


func _remove_entry(entry: Dictionary) -> void:
	_erase_identical(movers, entry)
	if entry.has("list_name"):
		_erase_identical(_list_for(String(entry["list_name"])), entry)
	var node: Node3D = entry["node"]
	if is_instance_valid(node):
		node.queue_free()


func _list_for(list_name: String) -> Array:
	match list_name:
		"hazards":
			return hazards
		"pickups":
			return pickups
		"aliens":
			return aliens
	return bolts


# Erase by identity (is_same), not by content, so entries never compare equal by accident.
func _erase_identical(list: Array, entry: Dictionary) -> void:
	for i in range(list.size()):
		if is_same(list[i], entry):
			list.remove_at(i)
			return


func _update_life(delta: float) -> void:
	for entry in movers.duplicate():
		if float(entry["life"]) > 0.0:
			entry["life"] = float(entry["life"]) - delta
			if float(entry["life"]) <= 0.0:
				_remove_entry(entry)


func _apply_positions() -> void:
	for entry in movers:
		var node: Node3D = entry["node"]
		if is_instance_valid(node):
			node.position = Vector3(float(entry["x"]), float(entry["y"]), float(entry["z"]) - ship_route_z)


# ---------------------------------------------------------------- presentation

func _animate_ship(delta: float, speed: float) -> void:
	ship.rotation.z = lerpf(ship.rotation.z, -steer_value * 0.22, 1.0 - exp(-7.0 * delta))
	ship.rotation.x = sin(elapsed * 1.5) * 0.012
	ship.position.y = SHIP_RESTING_Y + sin(elapsed * 2.0) * 0.045
	var power: float = 1.0
	if boost_active:
		power += 0.25
	if warp_active:
		power += 0.6
	for i in range(ship_flames.size()):
		var flame: MeshInstance3D = ship_flames[i]
		flame.scale = Vector3(1.0, 1.0, power * (0.92 + 0.14 * sin(elapsed * 38.0 + float(i) * 1.7)))


func _update_camera(delta: float) -> void:
	var fov_target: float = 88.0 if warp_active else (76.0 if boost_active else 70.0)
	camera.fov = lerpf(camera.fov, fov_target, 1.0 - exp(-3.0 * delta))
	shake = maxf(0.0, shake - 2.5 * delta)
	var jitter := Vector3(rng.randf_range(-1.0, 1.0), rng.randf_range(-1.0, 1.0), 0.0) * shake * 0.35
	camera.position = Vector3(ship.position.x * 0.45, ship.position.y + 2.1, 7.2) + jitter
	camera.look_at(Vector3(ship.position.x * 0.25, ship.position.y * 0.5 + 0.8, -60.0), Vector3.UP)
	# A gentle roll into turns gives the view more depth and motion.
	camera_roll = lerpf(camera_roll, -steer_value * 0.07, 1.0 - exp(-4.0 * delta))
	camera.rotate_object_local(Vector3.BACK, camera_roll)


func _update_streaks(speed: float) -> void:
	streaks.speed_scale = 1.0 if bh_state == "transit" else time_scale
	ship_dust.speed_scale = streaks.speed_scale
	ship_dust.initial_velocity_min = speed * 0.35
	ship_dust.initial_velocity_max = speed * 0.4
	streaks.initial_velocity_min = speed * 0.98
	streaks.initial_velocity_max = speed * 1.02


func _update_hud() -> void:
	var nearest: Dictionary = route.planet(nearest_index)
	var arrive_units: float = maxf(0.0, float(nearest["units"]) - traveled())
	var previous_units: float = 0.0 if nearest_index == 0 else float(route.units(nearest_index - 1))
	var span: float = maxf(1.0, float(nearest["units"]) - previous_units)
	var progress: float = clampf((traveled() - previous_units) / span, 0.0, 1.0)
	var lines: Array = []
	for k in range(0, 5):
		var p: Dictionary = route.planet(nearest_index + k)
		lines.append("%s   %s" % [p["name"], HudScript.million_km(maxf(0.0, float(p["units"]) - traveled()))])
	var in_jump: bool = bh_state == "transit"
	var speed_factor: float = 1.0 if in_jump else time_scale
	var speed_prefix: String = "BLACK HOLE   " if in_jump else ("WARP   " if warp_active else "")
	hud.update({
		"speed_text": speed_prefix + HudScript.speed_km(current_speed * speed_factor),
		"travelled_text": HudScript.million_km(traveled()),
		"energy_text": HudScript.commas(energy),
		"diamonds_text": HudScript.commas(total_diamonds),
		"best_text": HudScript.million_km(float(best_miles) / UNIT_MILES),
		"boost_ratio": boost_energy / 100.0,
		"planet": {
			"name": nearest["name"],
			"type": nearest["type"],
			"gravity": nearest["gravity"],
			"temp": nearest["temp"],
			"moons": nearest["moons"],
			"galaxy_name": route.galaxy_name(int(nearest["galaxy"])),
		},
		"remaining_text": HudScript.million_km(arrive_units),
		"progress": progress,
		"route_lines": lines,
	})
	hud.set_map_state({
		"traveled": traveled(),
		"nearest": nearest_index,
		"bh_active": bh_state == "approach",
		"bh_units": bh_units,
	})


func _show_message(text: String, seconds: float) -> void:
	hud.set_message(text)
	message_time = seconds


func _update_message_timer(delta: float) -> void:
	if message_time > 0.0:
		message_time -= delta
		if message_time <= 0.0:
			hud.set_message("")


# ---------------------------------------------------------------- black holes

# Every 50 million km a black hole appears ahead. Entering it carries the ship to the next
# destination (at least 29 million km ahead) in exactly 1 minute of real time, whatever the speed setting.
func _update_black_hole(delta: float) -> void:
	if bh_state == "none":
		if not warp_active and traveled() >= next_bh_units:
			_start_approach()
	elif bh_state == "approach":
		if is_instance_valid(black_hole_disk):
			black_hole_disk.rotate_y(delta * 0.9)
		if traveled() >= bh_units - 10.0:
			_begin_transit()


func _jump_destination() -> int:
	for i in range(nearest_index, nearest_index + 200):
		var p: Dictionary = route.planet(i)
		if not bool(p["warp_before"]) and float(p["units"]) - traveled() >= BH_JUMP_MIN_UNITS:
			return i
	return nearest_index + 1


func _start_approach() -> void:
	bh_state = "approach"
	bh_dest = _jump_destination()
	bh_units = traveled() + 260.0
	var node := Node3D.new()
	add_child(node)
	var core := MeshInstance3D.new()
	var core_mesh := SphereMesh.new()
	core_mesh.radius = 7.0
	core_mesh.height = 14.0
	core.mesh = core_mesh
	var void_mat := StandardMaterial3D.new()
	void_mat.albedo_color = Color(0.0, 0.0, 0.0)
	void_mat.roughness = 1.0
	core.material_override = void_mat
	node.add_child(core)
	black_hole_disk = MeshInstance3D.new()
	var disk_mesh := TorusMesh.new()
	disk_mesh.inner_radius = 8.5
	disk_mesh.outer_radius = 17.0
	black_hole_disk.mesh = disk_mesh
	black_hole_disk.rotation_degrees = Vector3(70.0, 0.0, 0.0)
	black_hole_disk.material_override = _glow_material(Color(1.0, 0.55, 0.2), 2.6)
	node.add_child(black_hole_disk)
	var halo := MeshInstance3D.new()
	var halo_mesh := TorusMesh.new()
	halo_mesh.inner_radius = 17.4
	halo_mesh.outer_radius = 18.0
	halo.mesh = halo_mesh
	halo.rotation_degrees = Vector3(70.0, 0.0, 0.0)
	halo.material_override = _glow_material(Color(0.6, 0.4, 0.7), 1.0)
	node.add_child(halo)
	black_hole_entry = _add_mover(node, 0.0, 0.0, -bh_units)
	_show_message("BLACK HOLE AHEAD\n\nENTER IT TO REACH %s IN 1 MINUTE" % route.planet(bh_dest)["name"], 6.0)


func _begin_transit() -> void:
	bh_state = "transit"
	transit_start = traveled()
	transit_distance = float(route.units(bh_dest)) - transit_start
	transit_timer = 0.0
	boost_active = false
	message_time = 0.0
	if not black_hole_entry.is_empty():
		_remove_entry(black_hole_entry)
		black_hole_entry = {}
	# Nothing else is shown during the jump: no stars, planets, asteroids or ships.
	for group in [hazards, pickups, aliens, bolts]:
		for entry in group.duplicate():
			_remove_entry(entry)
	for key in tile_entries.keys():
		_remove_entry(tile_entries[key])
	tile_entries.clear()
	for key in planet_entries.keys():
		_remove_entry(planet_entries[key]["entry"])
	planet_entries.clear()
	sky_sphere.visible = false
	var streak_box := streaks.mesh as BoxMesh
	if streak_box != null:
		streak_box.size = Vector3(0.05, 0.05, 7.0)
	streaks.amount = 420
	hud.set_flash(0.6)


func _update_transit(delta: float) -> void:
	transit_timer += delta
	var f: float = clampf(transit_timer / BH_TRANSIT_SECONDS, 0.0, 1.0)
	ship_route_z = -(transit_start + transit_distance * f)
	current_speed = transit_distance / BH_TRANSIT_SECONDS
	var remaining: int = int(ceil(maxf(0.0, BH_TRANSIT_SECONDS - transit_timer)))
	hud.set_message("BLACK HOLE JUMP\n\n%d:%02d remaining" % [remaining / 60, remaining % 60])
	if f >= 1.0:
		_end_transit()


func _end_transit() -> void:
	bh_state = "none"
	nearest_index = bh_dest
	ship_route_z = -float(route.units(bh_dest))
	next_bh_units = traveled() + BH_INTERVAL_UNITS
	sky_sphere.visible = true
	var streak_box := streaks.mesh as BoxMesh
	if streak_box != null:
		streak_box.size = Vector3(0.035, 0.035, 2.2)
	streaks.amount = 220
	current_speed = _speed_now()
	var dest: Dictionary = route.planet(bh_dest)
	hud.set_flash(0.5)
	_show_message("OUT OF THE BLACK HOLE\n\nARRIVED AT %s\n%s travelled in 1 minute" % [
		dest["name"], HudScript.million_km(transit_distance)], 7.0)


# ---------------------------------------------------------------- pause, restart, save

func _on_pause_pressed() -> void:
	if game_over:
		if repair_phase == "":
			_show_crash_menu()
		return
	_set_paused(not paused)


func _set_paused(value: bool) -> void:
	paused = value
	streaks.speed_scale = 0.0 if paused else time_scale
	if paused:
		boost_active = false
		hud.set_pause_text("RESUME")
		_show_message("", 0.0)
		_show_pause_menu()
	else:
		hud.set_pause_text("II  PAUSE")
		hud.hide_menu()
		_show_message("", 0.0)


func _on_speed_selected(index: int) -> void:
	speed_level = clampi(index, 0, SPEED_SCALES.size() - 1)
	time_scale = float(SPEED_SCALES[speed_level])
	hud.set_speed_level(speed_level)
	streaks.speed_scale = 0.0 if paused else time_scale
	_save()
	var names: Array = ["SLOW", "MEDIUM", "FAST"]
	_show_message("SPEED   %s" % names[speed_level], 1.5)


func _restart() -> void:
	get_tree().reload_current_scene()


func _save() -> void:
	SaveData.save_data({
		"best_miles": best_miles,
		"total_energy": total_energy,
		"total_diamonds": total_diamonds,
		"speed_level": speed_level,
	})


# ---------------------------------------------------------------- menus, save slots, repair

func _show_crash_menu() -> void:
	hud.show_menu("SHIP DAMAGED", "The ship was destroyed at %s travelled.\n\nRESTART begins a new flight from Earth.\nREPAIR TO PLAY repairs the ship and continues from this exact place.\nSAVE GAME keeps this place for later.\n\nEnergy and diamonds are kept." % HudScript.million_km(traveled()), [
		{"id": "restart", "text": "RESTART   (from Earth)", "enabled": true},
		{"id": "repair", "text": "REPAIR TO PLAY   (from this place)", "enabled": true},
		{"id": "save", "text": "SAVE GAME", "enabled": true},
		{"id": "menu", "text": "MAIN MENU", "enabled": true},
	])


func _show_pause_menu() -> void:
	hud.show_menu("FLIGHT PAUSED", "The universe is holding still.\n\nESC or RESUME continues the flight.", [
		{"id": "resume", "text": "RESUME", "enabled": true},
		{"id": "save", "text": "SAVE GAME", "enabled": true},
		{"id": "menu", "text": "MAIN MENU", "enabled": true},
	])


func _show_save_menu() -> void:
	var options: Array = []
	for slot in range(1, 4):
		var info: Dictionary = SaveData.read_slot(slot)
		var label: String = "SLOT %d   ·   EMPTY" % slot
		if not info.is_empty():
			label = "SLOT %d   ·   %s   ·   %s" % [slot, info["summary"], info["saved_at"]]
		options.append({"id": "slot_%d" % slot, "text": label, "enabled": true})
	options.append({"id": save_return, "text": "BACK", "enabled": true})
	hud.show_menu("SAVE GAME", "Choose a slot. Load it later from the main menu (LOAD GAME), and the ship continues from the same place.", options)


func _on_menu_choice(id: String) -> void:
	match id:
		"restart":
			_restart()
		"repair":
			_start_repair()
		"save":
			save_return = "crash_menu" if game_over else "pause_menu"
			_show_save_menu()
		"resume":
			_set_paused(false)
		"menu":
			get_tree().change_scene_to_file(COVER_SCENE)
		"crash_menu":
			_show_crash_menu()
		"pause_menu":
			_show_pause_menu()
		"slot_1", "slot_2", "slot_3":
			_save_to_slot(int(id.substr(5)))


func _save_to_slot(slot: int) -> void:
	if bh_state != "none" or repair_phase != "":
		_show_message("SAVING IS NOT AVAILABLE DURING A BLACK HOLE JUMP OR A REPAIR", 3.0)
		return
	var data: Dictionary = {
		"ship_route_z": ship_route_z,
		"nearest_index": nearest_index,
		"energy": energy,
		"speed_level": speed_level,
		"next_bh_units": next_bh_units,
		"ship_x": target_x,
		"summary": "%s   ·   next %s" % [HudScript.million_km(traveled()), route.planet(nearest_index)["name"]],
		"saved_at": "%s %s" % [Time.get_date_string_from_system(), Time.get_time_string_from_system()],
	}
	SaveData.write_slot(slot, data)
	_show_message("SAVED TO SLOT %d" % slot, 2.5)
	_show_save_menu()


func _apply_slot(slot: int) -> bool:
	var data: Dictionary = SaveData.read_slot(slot)
	if data.is_empty():
		return false
	ship_route_z = float(data["ship_route_z"])
	nearest_index = int(data["nearest_index"])
	energy = int(data["energy"])
	speed_level = clampi(int(data["speed_level"]), 0, SPEED_SCALES.size() - 1)
	time_scale = float(SPEED_SCALES[speed_level])
	next_bh_units = float(data["next_bh_units"])
	target_x = float(data["ship_x"])
	ship.position.x = target_x
	boost_energy = 100.0
	bh_state = "none"
	game_over = false
	hud.set_speed_level(speed_level)
	_clear_corridor()
	return true


func _start_repair() -> void:
	hud.hide_menu()
	repair_phase = "countdown"
	repair_timer = 0.0
	message_time = 0.0
	hud.set_message("SHIP DAMAGED   ·   REPAIR STARTING")
	hud.show_big("3")
	repair_sparks = CPUParticles3D.new()
	repair_sparks.local_coords = true
	repair_sparks.amount = 70
	repair_sparks.lifetime = 0.7
	repair_sparks.explosiveness = 0.2
	repair_sparks.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
	repair_sparks.emission_sphere_radius = 1.8
	repair_sparks.direction = Vector3.UP
	repair_sparks.spread = 180.0
	repair_sparks.initial_velocity_min = 1.0
	repair_sparks.initial_velocity_max = 3.0
	repair_sparks.gravity = Vector3(0.0, -1.5, 0.0)
	var spark := SphereMesh.new()
	spark.radius = 0.06
	spark.height = 0.12
	repair_sparks.mesh = spark
	repair_sparks.material_override = _glow_material(Color(1.0, 0.75, 0.4), 2.5)
	repair_sparks.emitting = false
	ship.add_child(repair_sparks)
	repair_ring = MeshInstance3D.new()
	var torus := TorusMesh.new()
	torus.inner_radius = 1.9
	torus.outer_radius = 2.05
	repair_ring.mesh = torus
	repair_ring.rotation_degrees = Vector3(90.0, 0.0, 0.0)
	repair_ring.material_override = _glow_material(Color(0.6, 0.9, 0.7), 1.1)
	repair_ring.visible = false
	ship.add_child(repair_ring)


# Three seconds of countdown (3, 2, 1), then five seconds of repair with sparks and a rotating ring.
func _update_repair(delta: float) -> void:
	repair_timer += delta
	if repair_phase == "countdown":
		var left: int = int(ceil(3.0 - repair_timer))
		hud.show_big(str(maxi(left, 1)))
		if repair_timer >= 3.0:
			repair_phase = "repairing"
			repair_timer = 0.0
			hud.show_big("")
			repair_ring.visible = true
			repair_sparks.emitting = true
	elif repair_phase == "repairing":
		repair_ring.rotate_y(delta * 3.0)
		ship.visible = int(elapsed * 14.0) % 3 != 0
		var ratio: float = clampf(repair_timer / 5.0, 0.0, 1.0)
		hud.set_message("SHIP REPAIR IN PROGRESS\n\n%d%%   ·   %d s left" % [
			int(ratio * 100.0), int(ceil(maxf(0.0, 5.0 - repair_timer)))])
		if repair_timer >= 5.0:
			_finish_repair()


func _finish_repair() -> void:
	repair_phase = ""
	game_over = false
	shake = 0.0
	ship.visible = true
	if repair_ring != null:
		repair_ring.queue_free()
		repair_ring = null
	if repair_sparks != null:
		repair_sparks.queue_free()
		repair_sparks = null
	boost_energy = 100.0
	_clear_corridor()
	hud.set_pause_text("II  PAUSE")
	hud.show_big("")
	hud.set_flash(0.35)
	_show_message("SHIP REPAIRED\n\nBack in flight, from the same place", 4.0)


# Remove the obstacles right in front of the ship, so it does not hit the same object again.
func _clear_corridor() -> void:
	for h in hazards.duplicate():
		var hz: float = float(h["z"])
		if hz > ship_route_z - 120.0 and hz < ship_route_z + 6.0:
			_remove_entry(h)
	for a in aliens.duplicate():
		var az: float = float(a["z"])
		if az > ship_route_z - 90.0 and az < ship_route_z + 6.0:
			_remove_entry(a)
	for b in bolts.duplicate():
		_remove_entry(b)


func _build_dust() -> void:
	# Motes drifting past the ship (in the ship's own space), so flight has depth.
	ship_dust = CPUParticles3D.new()
	ship_dust.local_coords = true
	ship_dust.amount = 140
	ship_dust.lifetime = 4.0
	ship_dust.preprocess = 4.0
	ship_dust.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	ship_dust.emission_box_extents = Vector3(7.0, 3.5, 10.0)
	ship_dust.position = Vector3(0.0, 0.0, -6.0)
	ship_dust.direction = Vector3(0.0, 0.0, 1.0)
	ship_dust.spread = 4.0
	ship_dust.initial_velocity_min = 0.0
	ship_dust.initial_velocity_max = 0.0
	ship_dust.gravity = Vector3.ZERO
	ship_dust.scale_amount_min = 0.5
	ship_dust.scale_amount_max = 1.4
	var speck := SphereMesh.new()
	speck.radius = 0.03
	speck.height = 0.06
	speck.radial_segments = 6
	speck.rings = 3
	var speck_mat := StandardMaterial3D.new()
	speck_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	speck_mat.albedo_color = Color(0.9, 0.82, 0.7, 0.6)
	speck_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	speck.material = speck_mat
	ship_dust.mesh = speck
	ship_dust.emitting = true
	ship.add_child(ship_dust)


# ---------------------------------------------------------------- materials

func _plain_material(color: Color, roughness: float) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = roughness
	material.metallic = 0.4
	return material


func _glow_material(color: Color, energy_value: float) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.emission_enabled = true
	material.emission = color
	material.emission_energy_multiplier = energy_value
	return material


func _tile_box(parent: Node3D, pos: Vector3, size: Vector3, material: Material) -> void:
	var node := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	node.mesh = mesh
	node.position = pos
	node.material_override = material
	parent.add_child(node)
