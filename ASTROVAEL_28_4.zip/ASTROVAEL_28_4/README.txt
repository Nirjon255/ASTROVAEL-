ASTROVAEL 28.4 - Endless

Open this folder in Godot 4.7 by importing project.godot.
Renderer: Compatibility (GL Compatibility).
Startup scene: scenes/Cover.tscn (the 3D cover). START GAME opens scenes/Main.tscn (the flight).

See VERSION_28_4_NOTES.txt for what changed, the bugs fixed, and the test status.
Keep the previous project folder as a backup.
